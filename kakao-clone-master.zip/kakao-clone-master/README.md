# kakao-clone

I'm going to make a clone of the kakaotalk
and
I have to fetch-origin every single time when i change my files in the repository
